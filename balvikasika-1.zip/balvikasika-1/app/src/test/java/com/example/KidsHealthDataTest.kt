package com.example

import com.example.data.model.AgeGroupId
import com.example.data.repository.KidsHealthData
import org.junit.Assert.*
import org.junit.Test

class KidsHealthDataTest {

    @Test
    fun testGoldenRulesCount() {
        assertEquals(8, KidsHealthData.goldenRules.size)
        assertTrue(KidsHealthData.goldenRules.any { it.title.contains("भूख का आदर करें") })
        assertTrue(KidsHealthData.goldenRules.any { it.title.contains("इंद्रधनुषी थाली") })
    }

    @Test
    fun testComplementaryFeedingData() {
        assertEquals(3, KidsHealthData.babyTextureStages.size)
        assertTrue(KidsHealthData.babyAllowedFoods.isNotEmpty())
        assertTrue(KidsHealthData.babyForbiddenFoods.any { it.first.contains("शहद") })
        assertTrue(KidsHealthData.babyForbiddenFoods.any { it.first.contains("सफेद नमक") })
    }

    @Test
    fun testAllAgeGroupsHaveDietPlans() {
        AgeGroupId.entries.forEach { ageGroup ->
            val plans = KidsHealthData.getDietPlanForAge(ageGroup)
            assertEquals("Age group $ageGroup should have 7 days of diet plan", 7, plans.size)
            plans.forEach { dayPlan ->
                assertTrue("Day ${dayPlan.dayNameHindi} should have meals", dayPlan.meals.isNotEmpty())
                assertTrue("Day ${dayPlan.dayNameHindi} should have Ayurvedic tip", dayPlan.dailyAyurvedicTip.isNotBlank())
            }
        }
    }

    @Test
    fun testRecipesCompleteness() {
        assertTrue(KidsHealthData.allRecipes.size >= 10)
        KidsHealthData.allRecipes.forEach { recipe ->
            assertTrue("Recipe ${recipe.titleHindi} must have ingredients", recipe.ingredients.isNotEmpty())
            assertTrue("Recipe ${recipe.titleHindi} must have steps", recipe.preparationSteps.isNotEmpty())
            assertTrue("Recipe ${recipe.titleHindi} must have benefits", recipe.ayurvedicBenefits.isNotBlank())
        }
    }

    @Test
    fun testGrowthStandards() {
        assertEquals(11, KidsHealthData.growthStandards.size)
        val infantStandard = KidsHealthData.growthStandards.first()
        assertEquals("6 महीने", infantStandard.ageLabel)
        assertEquals(6.5f, infantStandard.minWeightKg)
        assertEquals(8.5f, infantStandard.maxWeightKg)
    }

    @Test
    fun testMilestonesMap() {
        AgeGroupId.entries.forEach { ageGroup ->
            val info = KidsHealthData.milestonesMap[ageGroup]
            assertNotNull("Milestone info should exist for $ageGroup", info)
            assertTrue("Milestone info should have categories", info!!.categories.isNotEmpty())
        }
    }
}
