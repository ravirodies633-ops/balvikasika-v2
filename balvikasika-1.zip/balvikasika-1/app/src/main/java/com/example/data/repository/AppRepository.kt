package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.GrowthLogEntity
import kotlinx.coroutines.flow.Flow

class AppRepository(private val database: AppDatabase) {

    // Bookmarks
    val allBookmarks: Flow<List<BookmarkEntity>> = database.bookmarkDao().getAllBookmarks()

    fun isBookmarked(id: String): Flow<Boolean> = database.bookmarkDao().isBookmarked(id)

    suspend fun toggleBookmark(itemId: String, itemType: String, title: String, subtitle: String, currentlyBookmarked: Boolean) {
        if (currentlyBookmarked) {
            database.bookmarkDao().removeBookmark(itemId)
        } else {
            database.bookmarkDao().addBookmark(
                BookmarkEntity(
                    itemId = itemId,
                    itemType = itemType,
                    title = title,
                    subtitle = subtitle
                )
            )
        }
    }

    // Growth Logs
    val allGrowthLogs: Flow<List<GrowthLogEntity>> = database.growthLogDao().getAllGrowthLogs()

    suspend fun insertGrowthLog(log: GrowthLogEntity) {
        database.growthLogDao().insertGrowthLog(log)
    }

    suspend fun deleteGrowthLog(id: Long) {
        database.growthLogDao().deleteGrowthLog(id)
    }
}
