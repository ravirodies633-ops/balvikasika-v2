package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.SubcomposeAsyncImage
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import com.example.data.model.AgeGroupId
import com.example.ui.components.AgeCard
import com.example.ui.components.DisclaimerCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    uiState: UiState,
    onAgeGroupClick: (AgeGroupId) -> Unit,
    onNavigateToTab: (MainTab) -> Unit,
    onSearchClick: () -> Unit,
    onRuleClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppLightBackground)
            .testTag("screen_home"),
        contentPadding = PaddingValues(bottom = 36.dp)
    ) {
        // Premium Light Pastel Hero Section
        item {
            HeroHeader(
                onSearchClick = onSearchClick,
                onBannerClick = { onAgeGroupClick(AgeGroupId.INFANT_6_12M) }
            )
        }

        // Section: आयु वर्ग चुनें (Choose Age Group) - 2x2 Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PastelMint),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "👶", fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "आयु अनुसार आहार एवं विकास",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "अपने बच्चे का आयु वर्ग चुनें (4 प्रमुख पड़ाव)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 2x2 Grid with responsive cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        AgeCard(
                            ageGroup = AgeGroupId.INFANT_6_12M,
                            onClick = { onAgeGroupClick(AgeGroupId.INFANT_6_12M) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        AgeCard(
                            ageGroup = AgeGroupId.TODDLER_1_3Y,
                            onClick = { onAgeGroupClick(AgeGroupId.TODDLER_1_3Y) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        AgeCard(
                            ageGroup = AgeGroupId.PRESCHOOL_4_6Y,
                            onClick = { onAgeGroupClick(AgeGroupId.PRESCHOOL_4_6Y) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        AgeCard(
                            ageGroup = AgeGroupId.SCHOOL_7_10Y,
                            onClick = { onAgeGroupClick(AgeGroupId.SCHOOL_7_10Y) }
                        )
                    }
                }
            }
        }

        // Quick Clinical Shortcuts
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "त्वरित उपयोगी मार्गदर्शिका",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "दैनिक पालन हेतु महत्वपूर्ण क्लिनिकल सूत्र",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                QuickFeatureTile(
                    title = "पोषण के 10 स्वर्णिम नियम",
                    subtitle = "भूख का आदर, इंद्रधनुषी थाली, A2 घी व स्क्रीन-मुक्त भोजन",
                    icon = "⭐",
                    containerColor = PastelPeach,
                    accentColor = PastelPeachAccent,
                    borderColor = PastelPeachContainer,
                    onClick = { onNavigateToTab(MainTab.IMPORTANT) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                QuickFeatureTile(
                    title = "Picky Eaters: खाने में नखरे",
                    subtitle = "15-एक्सपोजर व नो-प्रेशर प्लेटिंग से बनाएं बच्चों को खुश",
                    icon = "🥗",
                    containerColor = PastelPink,
                    accentColor = PastelPinkAccent,
                    borderColor = PastelPinkContainer,
                    onClick = { onNavigateToTab(MainTab.IMPORTANT) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                QuickFeatureTile(
                    title = "ग्रोथ ट्रैकर चार्ट (WHO व IAP)",
                    subtitle = "6 माह से 10 वर्ष तक आदर्श वजन, लंबाई व विकास पड़ाव",
                    icon = "📊",
                    containerColor = PastelSkyBlue,
                    accentColor = PastelSkyAccent,
                    borderColor = PastelSkyContainer,
                    onClick = { onNavigateToTab(MainTab.GROWTH) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                QuickFeatureTile(
                    title = "प्राकृतिक रोग-प्रतिरोधक काढ़े",
                    subtitle = "स्वर्ण हल्दी दूध, तुलसी-मुलेठी काढ़ा व नस्य-अभ्यंग",
                    icon = "🛡️",
                    containerColor = PastelLavender,
                    accentColor = PastelLavenderAccent,
                    borderColor = PastelLavenderContainer,
                    onClick = { onNavigateToTab(MainTab.IMPORTANT) }
                )
            }
        }

        // Disclaimer at the bottom
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                DisclaimerCard()
            }
        }
    }
}

@Composable
fun HeroHeader(
    onSearchClick: () -> Unit,
    onBannerClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                add(SvgDecoder.Factory())
            }
            .build()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        PastelMint,
                        PastelPeach.copy(alpha = 0.6f),
                        AppLightBackground
                    )
                )
            )
            .padding(top = 22.dp, bottom = 14.dp, start = 20.dp, end = 20.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Badges & App Title
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, PastelMintContainer),
                shadowElevation = 1.dp,
                modifier = Modifier.padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🌿", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "आयुर्वेदिक एवं आधुनिक बाल पोषण",
                        style = MaterialTheme.typography.labelMedium,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "बालविकासिका",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = PrimaryDarkEmerald,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "बाल पोषण एवं विकास मार्गदर्शिका",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
            )

            Text(
                text = "स्वस्थ बचपन, सशक्त भविष्य (6 माह – 10 वर्ष)",
                style = MaterialTheme.typography.bodyMedium,
                color = PrimaryEmerald,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Search Trigger Button with soft shadow and large touch target
            Surface(
                onClick = onSearchClick,
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                shadowElevation = 3.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_search_trigger")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "खोजें",
                        tint = PrimaryEmerald,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "रेसिपी, आयु वर्ग या लक्षण खोजें...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 28-Day Meal Plan Custom Graphics Banner Image
            Surface(
                onClick = onBannerClick,
                shape = RoundedCornerShape(18.dp),
                color = Color.White,
                shadowElevation = 3.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("banner_meal_plan")
            ) {
                SubcomposeAsyncImage(
                    model = ImageRequest.Builder(context)
                        .data("https://i.postimg.cc/7LmFdz17/file-00000000fd8482078817c5481315a969.png")
                        .crossfade(true)
                        .build(),
                    imageLoader = imageLoader,
                    contentDescription = "28-दिवसीय विस्तृत मील प्लान",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1000f / 335f)
                        .clip(RoundedCornerShape(18.dp)),
                    loading = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1000f / 335f)
                                .background(PastelMint),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = PrimaryEmerald,
                                modifier = Modifier.size(28.dp),
                                strokeWidth = 2.5.dp
                            )
                        }
                    },
                    error = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1000f / 335f)
                                .background(PastelMint)
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "🥗 28-दिवसीय विस्तृत मील प्लान",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryDarkEmerald
                                )
                                Text(
                                    text = "शारीरिक-मानसिक विकास के चरण और स्वादिष्ट सुपाच्य रेसिपीज",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun QuickFeatureTile(
    title: String,
    subtitle: String,
    icon: String,
    containerColor: Color,
    accentColor: Color,
    borderColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(containerColor),
                contentAlignment = Alignment.Center
            ) {
                Text(text = icon, fontSize = 26.sp)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1
                )
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(containerColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
