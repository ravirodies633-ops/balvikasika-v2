package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClinicalTip
import com.example.data.repository.KidsHealthData
import com.example.ui.components.DisclaimerCard
import com.example.ui.theme.*

@Composable
fun ImportantThingsScreen(
    onToggleBookmark: (String, String, String, String) -> Unit,
    isBookmarked: (String) -> Boolean,
    onShare: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("RULES") }

    val categories = listOf(
        "RULES" to "10 स्वर्णिम नियम",
        "DIGESTION" to "जठराग्नि व भूख",
        "PICKY" to "Picky Eaters समाधान",
        "IMMUNITY" to "रोग-प्रतिरोधक काढ़े",
        "DO_DONT" to "क्या करें / क्या न करें"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppLightBackground)
            .testTag("screen_important_things"),
        contentPadding = PaddingValues(bottom = 36.dp)
    ) {
        item {
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 14.dp)) {
                    Text(
                        text = "जरूरी बातें एवं क्लिनिकल नियम",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryDarkEmerald
                    )
                    Text(
                        text = "डॉ. रविरज प्रजापति द्वारा प्रमाणित आयुर्वेदिक एवं बाल-पोषण सिद्धांत",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { (key, label) ->
                            val active = selectedCategory == key
                            FilterChip(
                                selected = active,
                                onClick = { selectedCategory = key },
                                label = {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryEmerald,
                                    selectedLabelColor = Color.White,
                                    containerColor = AppLightBackground
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = active,
                                    borderColor = if (active) PrimaryEmerald else CardBorder
                                ),
                                modifier = Modifier.height(38.dp)
                            )
                        }
                    }
                }
            }
        }

        // 1. 10 GOLDEN RULES
        if (selectedCategory == "RULES") {
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = PastelPeach,
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelPeachContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "📜 अभिभावकों के लिए पोषण के 10 स्वर्णिम नियम",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PastelPeachAccent
                        )
                        Text(
                            text = "भोजन केवल पेट भरने का साधन नहीं, बल्कि जीवन ऊर्जा का निर्माण है।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            items(KidsHealthData.goldenRules) { rule ->
                val ruleId = "rule_${rule.number}"
                val bookmarked = isBookmarked(ruleId)

                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(PastelPeach)
                                    .border(1.5.dp, PastelPeachContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = rule.emoji, fontSize = 24.sp)
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${rule.number}. ${rule.title}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = rule.englishTitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PastelPeachAccent,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            IconButton(
                                onClick = {
                                    onToggleBookmark(
                                        ruleId,
                                        "RULE",
                                        "${rule.number}. ${rule.title}",
                                        rule.englishTitle
                                    )
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                    contentDescription = "सेव करें",
                                    tint = if (bookmarked) PastelPeachAccent else TextMuted
                                )
                            }

                            IconButton(
                                onClick = {
                                    onShare(
                                        "🌟 स्वर्णिम नियम #${rule.number}: ${rule.title} (${rule.englishTitle})\n\n${rule.description}\n\n- बालविकासिका ऐप",
                                        rule.title
                                    )
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Share,
                                    contentDescription = "शेयर करें",
                                    tint = TextMuted
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = rule.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }

        // 2. DIGESTIVE FIRE (जठराग्नि)
        if (selectedCategory == "DIGESTION") {
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = PastelPeach,
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelPeachContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "🔥 \"रोगाः सर्वेऽपि मन्दोऽग्नौ\"",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PastelPeachAccent
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "आयुर्वेद का मूल सिद्धांत है कि समस्त शारीरिक रोग मंदाग्नि (कमजोर पाचन) से उत्पन्न होते हैं। यदि जठराग्नि प्रदीप्त है, तो खाया हुआ अन्न ओजस (Immunity) में परिवर्तित होता है।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "मंदाग्नि के प्रमुख लक्षण:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = PastelPeachAccent
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "• समय पर भूख न लगना या भोजन देखकर चिढ़ना\n• पेट में गैस, भारीपन, गुड़गुड़ाहट या पेट फूलना\n• कठोर मल या 2-3 दिन तक शौच न जाना (कब्ज)\n• जीभ पर सफेद मैल (आमरस/Toxins) जमना व मुंह से दुर्गंध",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            items(KidsHealthData.digestiveFireTips) { tip ->
                TipCard(
                    tip = tip,
                    onToggleBookmark = onToggleBookmark,
                    isBookmarked = isBookmarked,
                    onShare = onShare
                )
            }
        }

        // 3. PICKY EATERS (खाने में नखरे)
        if (selectedCategory == "PICKY") {
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = PastelMint,
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelMintContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "🥗 Picky Eaters: वैज्ञानिक समाधान",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryEmerald
                        )
                        Text(
                            text = "\"मेरा बच्चा दाल-रोटी या सब्जियां नहीं खाता!\" इसे सुलझाने के बाल मनोविज्ञान व आयुर्वेदिक तरीके:",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            items(KidsHealthData.pickyEatersGuide) { (title, content) ->
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryEmerald
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }

        // 4. IMMUNITY BOOSTERS
        if (selectedCategory == "IMMUNITY") {
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = PastelLavender,
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelLavenderContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "🛡️ प्राकृतिक रोग-प्रतिरोधक क्षमता (Immunity Boosters)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PastelLavenderAccent
                        )
                        Text(
                            text = "बार-बार सर्दी-जुकाम, खांसी व बुखार कमजोर रोग प्रतिरोधक क्षमता का लक्षण है। इन नुस्खों से सुरक्षा चक्र मजबूत करें:",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            items(KidsHealthData.immunityBoosters) { tip ->
                TipCard(
                    tip = tip,
                    onToggleBookmark = onToggleBookmark,
                    isBookmarked = isBookmarked,
                    onShare = onShare
                )
            }
        }

        // 5. DO'S AND DON'TS (क्या करें / क्या न करें)
        if (selectedCategory == "DO_DONT") {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    // क्या करें Card
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = PastelMint,
                        border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelMintContainer),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "✅", fontSize = 22.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "क्या करें (Do's)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryEmerald
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            val dos = listOf(
                                "हमेशा ताजा, हल्का गुनगुना और थोड़ा घी युक्त भोजन दें।",
                                "थाली में रंग-बिरंगे प्राकृतिक फल व सब्जियां शामिल करें (इंद्रधनुषी थाली)।",
                                "बच्चों को स्वयं अपने हाथों से खाने दें (Self-feeding)।",
                                "दूध में सफेद चीनी के स्थान पर ताड़ की चीनी, मिश्री या खजूर सिरप मिलाएं।",
                                "गर्मियों में चना सत्तू व मटके का पानी दें।",
                                "प्रतिदिन 15-20 मिनट सुबह की धूप में खेलने दें (प्राकृतिक विटामिन डी)।",
                                "सब्जियां धोने या छीलने में बच्चों को शामिल करें।"
                            )
                            dos.forEach { item ->
                                Text(
                                    text = "• $item",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    lineHeight = 22.sp,
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // क्या न करें Card
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = PastelPink,
                        border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelPinkContainer),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "❌", fontSize = 22.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "क्या न करें (Don'ts)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PastelPinkAccent
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            val donts = listOf(
                                "बच्चे को कभी भी जबरदस्ती (Force-feeding) न कराएं।",
                                "टीवी या मोबाइल फोन दिखाते हुए खाना कभी न खिलाएं।",
                                "1 वर्ष से छोटे शिशु को शहद, सफेद नमक या चीनी न दें।",
                                "भोजन के तुरंत पहले या बाद में ढेर सारा ठंडा पानी न पिलाएं।",
                                "भोजन से 2 घंटे पहले कोई भी बिस्किट, जूस या स्नैक न दें।",
                                "शिशु को लेटी हुई अवस्था में कभी खाना न खिलाएं।",
                                "हर छोटी छींक या जुकाम पर तुरंत एंटीबायोटिक्स न दें।"
                            )
                            donts.forEach { item ->
                                Text(
                                    text = "• $item",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    lineHeight = 22.sp,
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Disclaimer
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                DisclaimerCard()
            }
        }
    }
}

@Composable
fun TipCard(
    tip: ClinicalTip,
    onToggleBookmark: (String, String, String, String) -> Unit,
    isBookmarked: (String) -> Boolean,
    onShare: (String, String) -> Unit
) {
    val tipId = "tip_${tip.title.hashCode()}"
    val bookmarked = isBookmarked(tipId)

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(PastelMint)
                        .border(1.5.dp, PastelMintContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = tip.emoji, fontSize = 24.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tip.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${tip.category} • ${tip.forAge}",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = {
                        onToggleBookmark(
                            tipId,
                            "TIP",
                            tip.title,
                            tip.category
                        )
                    },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                        contentDescription = "सेव करें",
                        tint = if (bookmarked) PrimaryEmerald else TextMuted
                    )
                }

                IconButton(
                    onClick = {
                        onShare(
                            "🌿 ${tip.title} (${tip.category})\nउपयोग: ${tip.forAge}\n\nविधि:\n${tip.instructions}\n\nलाभ: ${tip.benefits}\n\n- बालविकासिका ऐप",
                            tip.title
                        )
                    },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "शेयर करें",
                        tint = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = PastelMint.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "बनाने व सेवन की विधि:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = tip.instructions,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 21.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.Top) {
                Text(text = "✨", fontSize = 16.sp, modifier = Modifier.padding(end = 6.dp, top = 2.dp))
                Column {
                    Text(
                        text = "आयुर्वेदिक लाभ:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Text(
                        text = tip.benefits,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
