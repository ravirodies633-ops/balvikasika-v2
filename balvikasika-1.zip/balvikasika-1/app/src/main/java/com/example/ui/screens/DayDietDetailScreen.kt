package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DayDietPlan
import com.example.data.model.MealSlot
import com.example.ui.components.DisclaimerCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayDietDetailScreen(
    dayPlan: DayDietPlan,
    onBack: () -> Unit,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "${dayPlan.dayNameHindi} आहार चार्ट",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${dayPlan.ageGroupId.title} (${dayPlan.dayNameEnglish})",
                            style = MaterialTheme.typography.labelSmall,
                            color = PrimaryEmerald,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("btn_day_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं",
                            tint = PrimaryEmerald
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onToggleBookmark,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                            contentDescription = "बुकमार्क करें",
                            tint = if (isBookmarked) PrimaryEmerald else TextSecondary
                        )
                    }
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = "शेयर करें",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(AppLightBackground)
                .padding(innerPadding)
                .testTag("screen_day_detail_${dayPlan.dayId}"),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 36.dp)
        ) {
            // Note Banner
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = PastelMint,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PastelMintContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "ℹ️", fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp))
                        Text(
                            text = dayPlan.note,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = PrimaryDarkEmerald,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            // Meal items in chronological order
            itemsIndexed(dayPlan.meals) { index, meal ->
                MealTimelineCard(
                    meal = meal,
                    index = index + 1,
                    totalMeals = dayPlan.meals.size
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Daily Ayurvedic Tip Banner
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = PastelPeach,
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, PastelPeachContainer),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(text = "🌿", fontSize = 24.sp, modifier = Modifier.padding(end = 10.dp, top = 2.dp))
                        Column {
                            Text(
                                text = "आयुर्वेदिक क्लिनिकल टिप",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = PastelPeachAccent
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = dayPlan.dailyAyurvedicTip.removePrefix("दैनिक आयुर्वेदिक टिप: "),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }

            // Disclaimer
            item {
                Spacer(modifier = Modifier.height(16.dp))
                DisclaimerCard()
            }
        }
    }
}

@Composable
fun MealTimelineCard(
    meal: MealSlot,
    index: Int,
    totalMeals: Int
) {
    val mealIcon = when {
        meal.timeLabel.contains("सुबह (7", ignoreCase = true) -> "🌅"
        meal.timeLabel.contains("नाश्ता", ignoreCase = true) -> "🥣"
        meal.timeLabel.contains("मध्याह्न", ignoreCase = true) || meal.timeLabel.contains("टिफिन", ignoreCase = true) -> "🥪"
        meal.timeLabel.contains("दोपहर", ignoreCase = true) -> "🍲"
        meal.timeLabel.contains("मध्य-दोपहर", ignoreCase = true) -> "🥛"
        meal.timeLabel.contains("शाम", ignoreCase = true) -> "🍎"
        meal.timeLabel.contains("रात", ignoreCase = true) -> "🍛"
        meal.timeLabel.contains("सोते समय", ignoreCase = true) -> "🌙"
        else -> "🍽️"
    }

    val pastelTheme = when (index % 4) {
        0 -> PastelPeach to PastelPeachContainer
        1 -> PastelMint to PastelMintContainer
        2 -> PastelSkyBlue to PastelSkyContainer
        else -> PastelLavender to PastelLavenderContainer
    }

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(pastelTheme.first)
                        .border(1.5.dp, pastelTheme.second, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = mealIcon, fontSize = 24.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = meal.timeLabel,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "समय $index / $totalMeals",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = pastelTheme.first.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "आहार सामग्री:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = meal.mealName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        lineHeight = 22.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.Top) {
                Text(text = "✨", fontSize = 14.sp, modifier = Modifier.padding(end = 6.dp, top = 2.dp))
                Column {
                    Text(
                        text = "आयुर्वेदिक व पोषण लाभ:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Text(
                        text = meal.ayurvedicBenefit,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
