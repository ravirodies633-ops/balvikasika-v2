package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = PrimaryEmerald,
    onPrimary = Color.White,
    primaryContainer = PastelMint,
    onPrimaryContainer = OnPrimaryMint,
    secondary = CoralSecondary,
    onSecondary = Color.White,
    secondaryContainer = PastelPeach,
    onSecondaryContainer = OnHoneyContainer,
    tertiary = PastelPeachAccent,
    onTertiary = Color.White,
    tertiaryContainer = PastelPeach,
    onTertiaryContainer = OnHoneyContainer,
    background = AppLightBackground,
    onBackground = TextPrimary,
    surface = CardBackground,
    onSurface = TextPrimary,
    surfaceVariant = PastelPeach,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF66BB6A),
    onPrimary = Color(0xFF003915),
    primaryContainer = Color(0xFF13532F),
    onPrimaryContainer = Color(0xFFB8F5CD),
    secondary = Color(0xFFFF8A65),
    onSecondary = Color(0xFF4A1800),
    secondaryContainer = Color(0xFF6F2900),
    onSecondaryContainer = Color(0xFFFFDBCD),
    tertiary = Color(0xFFFFB74D),
    onTertiary = Color(0xFF452B00),
    background = Color(0xFF141916),
    onBackground = Color(0xFFE2E8E4),
    surface = Color(0xFF1C221F),
    onSurface = Color(0xFFE2E8E4),
    surfaceVariant = Color(0xFF252E2A),
    onSurfaceVariant = Color(0xFFBCC7C0)
)

@Composable
fun BalVikasikaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent clean light pastel theme for warmth and trust
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
