package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookmarkEntity
import com.example.data.model.Recipe
import com.example.data.repository.KidsHealthData
import com.example.ui.theme.*

@Composable
fun BookmarksScreen(
    bookmarks: List<BookmarkEntity>,
    onRemoveBookmark: (String, String, String, String) -> Unit,
    onOpenRecipe: (Recipe) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppLightBackground)
            .testTag("screen_bookmarks"),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 40.dp)
    ) {
        item {
            Column {
                Text(
                    text = "सेव किए गए सुझाव व रेसिपी",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryDarkEmerald
                )
                Text(
                    text = "आपकी पसंदीदा रेसिपीज और महत्वपूर्ण आयुर्वेदिक नियम (${bookmarks.size})",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        if (bookmarks.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(PastelMint)
                                .border(1.5.dp, PastelMintContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🔖", fontSize = 36.sp)
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "कोई बुकमार्क नहीं मिला",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "रेसिपी या जरूरी बातों के कार्ड पर दिए गए बुकमार्क आइकन पर टैप करके उन्हें यहाँ आसानी से एक्सेस करें।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        } else {
            items(bookmarks) { bookmark ->
                val recipe = KidsHealthData.allRecipes.find { it.id == bookmark.itemId }

                Surface(
                    onClick = {
                        if (recipe != null) {
                            onOpenRecipe(recipe)
                        }
                    },
                    shape = RoundedCornerShape(22.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(if (recipe != null) PastelPeach else PastelMint)
                                .border(1.dp, if (recipe != null) PastelPeachContainer else PastelMintContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (recipe != null) recipe.iconEmoji else "⭐",
                                fontSize = 24.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = bookmark.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = bookmark.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = PrimaryEmerald,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        IconButton(
                            onClick = {
                                onRemoveBookmark(
                                    bookmark.itemId,
                                    bookmark.itemType,
                                    bookmark.title,
                                    bookmark.subtitle
                                )
                            },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.BookmarkRemove,
                                contentDescription = "हटाएं",
                                tint = PastelPinkAccent
                            )
                        }
                    }
                }
            }
        }
    }
}
