package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppBottomNavigation
import com.example.ui.components.AppHeader
import com.example.ui.screens.*
import com.example.ui.theme.BalVikasikaTheme
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BalVikasikaTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val context = LocalContext.current
                var showSearchDialog by remember { mutableStateOf(false) }

                // Custom Back Navigation
                BackHandler(
                    enabled = uiState.selectedRecipe != null ||
                            uiState.selectedDayPlan != null ||
                            uiState.selectedAgeGroup != null ||
                            uiState.currentTab != MainTab.HOME
                ) {
                    when {
                        uiState.selectedRecipe != null -> viewModel.clearRecipe()
                        uiState.selectedDayPlan != null -> viewModel.clearDayPlan()
                        uiState.selectedAgeGroup != null -> viewModel.clearAgeGroupSelection()
                        uiState.currentTab != MainTab.HOME -> viewModel.selectTab(MainTab.HOME)
                    }
                }

                Scaffold(
                    topBar = {
                        // Show Top Bar if on main sub-tabs and not in sub-detail screens that have their own headers
                        if (uiState.selectedAgeGroup == null &&
                            uiState.selectedDayPlan == null &&
                            uiState.selectedRecipe == null &&
                            uiState.currentTab != MainTab.HOME
                        ) {
                            AppHeader(
                                title = when (uiState.currentTab) {
                                    MainTab.IMPORTANT -> "जरूरी बातें व क्लिनिकल टिप्स"
                                    MainTab.GROWTH -> "आयु अनुसार ग्रोथ ट्रैकर"
                                    MainTab.ABOUT -> "हमारे बारे में"
                                    MainTab.SAVED -> "सेव किए गए"
                                    else -> "बालविकासिका"
                                },
                                subtitle = "बाल पोषण एवं विकास मार्गदर्शिका",
                                actions = {
                                    IconButton(
                                        onClick = { showSearchDialog = true },
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .testTag("btn_top_search")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Search,
                                            contentDescription = "खोजें",
                                            tint = PrimaryEmerald
                                        )
                                    }
                                }
                            )
                        }
                    },
                    bottomBar = {
                        // Only show bottom navigation on top-level screens
                        if (uiState.selectedRecipe == null && uiState.selectedDayPlan == null) {
                            AppBottomNavigation(
                                currentTab = uiState.currentTab,
                                onTabSelected = { tab -> viewModel.selectTab(tab) }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = Triple(
                                uiState.currentTab,
                                uiState.selectedAgeGroup,
                                Pair(uiState.selectedDayPlan, uiState.selectedRecipe)
                            ),
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "ScreenTransition"
                        ) { (_, ageGroup, details) ->
                            val (dayPlan, recipe) = details

                            when {
                                recipe != null -> {
                                    RecipeDetailScreen(
                                        recipe = recipe,
                                        onBack = { viewModel.clearRecipe() },
                                        isBookmarked = viewModel.isBookmarked(recipe.id),
                                        onToggleBookmark = {
                                            viewModel.toggleBookmark(
                                                recipe.id,
                                                "RECIPE",
                                                recipe.titleHindi,
                                                recipe.ageGroupLabel
                                            )
                                        },
                                        onShare = {
                                            val shareText = "🍳 ${recipe.titleHindi} (${recipe.titleEnglish})\nआयु वर्ग: ${recipe.ageGroupLabel}\n\nसामग्री:\n" +
                                                    recipe.ingredients.joinToString("\n") { "• $it" } +
                                                    "\n\nआयुर्वेदिक लाभ: ${recipe.ayurvedicBenefits}\n\nसावधानी/टिप: ${recipe.cautionOrTip}\n\n- बालविकासिका ऐप"
                                            viewModel.shareContent(context, shareText, recipe.titleHindi)
                                        }
                                    )
                                }

                                dayPlan != null -> {
                                    DayDietDetailScreen(
                                        dayPlan = dayPlan,
                                        onBack = { viewModel.clearDayPlan() },
                                        isBookmarked = viewModel.isBookmarked(dayPlan.dayId),
                                        onToggleBookmark = {
                                            viewModel.toggleBookmark(
                                                dayPlan.dayId,
                                                "DAY_PLAN",
                                                "${dayPlan.dayNameHindi} आहार चार्ट",
                                                dayPlan.ageGroupId.title
                                            )
                                        },
                                        onShare = {
                                            val shareText = "📅 ${dayPlan.dayNameHindi} आहार चार्ट (${dayPlan.ageGroupId.title})\n\n" +
                                                    dayPlan.meals.joinToString("\n\n") { "⏰ ${it.timeLabel}: ${it.mealName}\nलाभ: ${it.ayurvedicBenefit}" } +
                                                    "\n\n${dayPlan.dailyAyurvedicTip}\n\n- बालविकासिका ऐप"
                                            viewModel.shareContent(context, shareText, "${dayPlan.dayNameHindi} आहार चार्ट")
                                        }
                                    )
                                }

                                ageGroup != null -> {
                                    AgeGroupScreen(
                                        ageGroupId = ageGroup,
                                        onBack = { viewModel.clearAgeGroupSelection() },
                                        onOpenDayPlan = { plan -> viewModel.selectDayPlan(plan) },
                                        onOpenRecipe = { r -> viewModel.selectRecipe(r) },
                                        onToggleBookmark = { id, type, title, sub ->
                                            viewModel.toggleBookmark(id, type, title, sub)
                                        },
                                        isBookmarked = { id -> viewModel.isBookmarked(id) },
                                        onShare = { text, title ->
                                            viewModel.shareContent(context, text, title)
                                        }
                                    )
                                }

                                else -> {
                                    when (uiState.currentTab) {
                                        MainTab.HOME -> {
                                            HomeScreen(
                                                uiState = uiState,
                                                onAgeGroupClick = { group -> viewModel.selectAgeGroup(group) },
                                                onNavigateToTab = { tab -> viewModel.selectTab(tab) },
                                                onSearchClick = { showSearchDialog = true },
                                                onRuleClick = { viewModel.selectTab(MainTab.IMPORTANT) }
                                            )
                                        }

                                        MainTab.IMPORTANT -> {
                                            ImportantThingsScreen(
                                                onToggleBookmark = { id, type, title, sub ->
                                                    viewModel.toggleBookmark(id, type, title, sub)
                                                },
                                                isBookmarked = { id -> viewModel.isBookmarked(id) },
                                                onShare = { text, title ->
                                                    viewModel.shareContent(context, text, title)
                                                }
                                            )
                                        }

                                        MainTab.GROWTH -> {
                                            GrowthTrackerScreen(
                                                growthLogs = uiState.growthLogs,
                                                onAddLog = { name, age, w, h, date, notes ->
                                                    viewModel.addGrowthLog(name, age, w, h, date, notes)
                                                },
                                                onDeleteLog = { id -> viewModel.deleteGrowthLog(id) }
                                            )
                                        }

                                        MainTab.ABOUT -> {
                                            AboutScreen()
                                        }

                                        MainTab.SAVED -> {
                                            BookmarksScreen(
                                                bookmarks = uiState.bookmarks,
                                                onRemoveBookmark = { id, type, title, sub ->
                                                    viewModel.toggleBookmark(id, type, title, sub)
                                                },
                                                onOpenRecipe = { r -> viewModel.selectRecipe(r) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Search Dialog Overlay
                    if (showSearchDialog) {
                        SearchDialog(
                            onDismiss = { showSearchDialog = false },
                            onOpenRecipe = { recipe ->
                                viewModel.selectRecipe(recipe)
                            }
                        )
                    }
                }
            }
        }
    }
}
