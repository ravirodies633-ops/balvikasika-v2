package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.SubcomposeAsyncImage
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import com.example.data.model.*
import com.example.data.repository.KidsHealthData
import com.example.ui.components.DisclaimerCard
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgeGroupScreen(
    ageGroupId: AgeGroupId,
    onBack: () -> Unit,
    onOpenDayPlan: (DayDietPlan) -> Unit,
    onOpenRecipe: (Recipe) -> Unit,
    onToggleBookmark: (String, String, String, String) -> Unit,
    isBookmarked: (String) -> Boolean,
    onShare: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val sectionTabs = listOf(
        "ALL" to "संपूर्ण गाइड",
        "DIET" to "साप्ताहिक डाइट",
        "RECIPES" to "पौष्टिक रेसिपी",
        "MILESTONES" to "विकास के चरण",
        "NUTRITION" to "पोषण व जरूरी नियम"
    )

    val (bgColor, accentColor, containerColor) = when (ageGroupId) {
        AgeGroupId.INFANT_6_12M -> Triple(InfantPastel, InfantAccent, InfantContainer)
        AgeGroupId.TODDLER_1_3Y -> Triple(ToddlerPastel, ToddlerAccent, ToddlerContainer)
        AgeGroupId.PRESCHOOL_4_6Y -> Triple(PreschoolPastel, PreschoolAccent, PreschoolContainer)
        AgeGroupId.SCHOOL_7_10Y -> Triple(SchoolPastel, SchoolAccent, SchoolContainer)
    }

    val milestoneInfo = KidsHealthData.milestonesMap[ageGroupId]
    val dietPlans = KidsHealthData.getDietPlanForAge(ageGroupId)
    val recipes = KidsHealthData.getRecipesForAge(ageGroupId)

    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val tabListState = rememberLazyListState()
    var manualSelectedTab by remember { mutableStateOf<String?>("ALL") }

    // Section indices for direct smooth scrolling
    val guideIndex = 0
    val dietIndex = 2
    val recipeIndex = dietIndex + 1 + dietPlans.size
    val milestoneIndex = recipeIndex + 1 + recipes.size
    val nutritionIndex = milestoneIndex + (if (milestoneInfo != null) 1 else 0)

    // Reset manual selection when user manually scrolls
    LaunchedEffect(listState.isScrollInProgress) {
        if (listState.isScrollInProgress) {
            manualSelectedTab = null
        }
    }

    val currentActiveTab by remember {
        derivedStateOf {
            manualSelectedTab ?: run {
                val idx = listState.firstVisibleItemIndex
                when {
                    idx >= nutritionIndex -> "NUTRITION"
                    idx >= milestoneIndex -> "MILESTONES"
                    idx >= recipeIndex -> "RECIPES"
                    idx >= dietIndex -> "DIET"
                    else -> "ALL"
                }
            }
        }
    }

    LaunchedEffect(currentActiveTab) {
        val tabIndex = sectionTabs.indexOfFirst { it.first == currentActiveTab }
        if (tabIndex >= 0) {
            tabListState.animateScrollToItem(tabIndex)
        }
    }

    val context = LocalContext.current
    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                add(SvgDecoder.Factory())
            }
            .build()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(1.5.dp, containerColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            SubcomposeAsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(ageGroupId.imageUrl)
                                    .crossfade(true)
                                    .build(),
                                imageLoader = imageLoader,
                                contentDescription = ageGroupId.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                error = {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = ageGroupId.emoji, fontSize = 20.sp)
                                    }
                                }
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = ageGroupId.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = ageGroupId.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = accentColor,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("btn_age_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं",
                            tint = PrimaryEmerald
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(AppLightBackground)
                .padding(innerPadding)
        ) {
            // Interactive 5 Top Tabs Row (Horizontally Scrollable)
            Surface(
                color = Color.White,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                LazyRow(
                    state = tabListState,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(sectionTabs) { (key, label) ->
                        val isActive = currentActiveTab == key
                        Surface(
                            onClick = {
                                manualSelectedTab = key
                                coroutineScope.launch {
                                    val targetIndex = when (key) {
                                        "ALL" -> 0
                                        "DIET" -> dietIndex
                                        "RECIPES" -> recipeIndex
                                        "MILESTONES" -> milestoneIndex
                                        "NUTRITION" -> nutritionIndex
                                        else -> 0
                                    }
                                    listState.animateScrollToItem(targetIndex)
                                }
                            },
                            shape = RoundedCornerShape(20.dp),
                            color = if (isActive) accentColor else Color.White,
                            border = androidx.compose.foundation.BorderStroke(
                                width = 1.dp,
                                color = if (isActive) accentColor else containerColor
                            ),
                            shadowElevation = if (isActive) 2.dp else 0.dp,
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("tab_${key.lowercase()}")
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isActive) Color.White else TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // LazyColumn with all 5 sections
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("screen_age_group_${ageGroupId.name.lowercase()}"),
                contentPadding = PaddingValues(bottom = 44.dp)
            ) {
                // Header summary banner (Item 0)
                item {
                    Surface(
                        color = bgColor,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 18.dp, top = 14.dp)
                        ) {
                            Text(
                                text = ageGroupId.description,
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextPrimary,
                                lineHeight = 26.sp
                            )
                        }
                    }
                }

                // 1. PRIMARY AGE GUIDE SECTION (Item 1)
                if (ageGroupId == AgeGroupId.INFANT_6_12M) {
                    item {
                        ComplementaryFeedingSection(
                            onShare = { text -> onShare(text, "पूरक आहार नियम") }
                        )
                    }
                } else if (ageGroupId == AgeGroupId.TODDLER_1_3Y) {
                    item {
                        ToddlerNutritionSection(
                            onShare = { text -> onShare(text, "टॉडलर पोषण सिद्धांत") }
                        )
                    }
                } else if (ageGroupId == AgeGroupId.PRESCHOOL_4_6Y) {
                    item {
                        PreschoolNutritionSection()
                    }
                } else if (ageGroupId == AgeGroupId.SCHOOL_7_10Y) {
                    item {
                        SchoolNutritionSection()
                    }
                }

                // 2. WEEKLY DIET PLAN (7 Days) (Item 2)
                item {
                    SectionTitle(
                        title = "साप्ताहिक डाइट प्लान (Weekly Diet)",
                        subtitle = "प्रत्येक दिन का विस्तृत समयबद्ध आहार चार्ट",
                        icon = "📅",
                        accentColor = accentColor
                    )
                }

                items(dietPlans) { dayPlan ->
                    DayDietCard(
                        dayPlan = dayPlan,
                        accentColor = accentColor,
                        containerColor = containerColor,
                        onClick = { onOpenDayPlan(dayPlan) }
                    )
                }

                // 3. RECIPES FOR THIS AGE
                item {
                    SectionTitle(
                        title = "पौष्टिक एवं स्वादिष्ट रेसिपीज",
                        subtitle = "डॉ. रविरज द्वारा अनुशंसित सुपाच्य घरेलू व्यंजन",
                        icon = "🥣",
                        accentColor = accentColor
                    )
                }

                items(recipes) { recipe ->
                    RecipeCard(
                        recipe = recipe,
                        isBookmarked = isBookmarked(recipe.id),
                        onToggleBookmark = {
                            onToggleBookmark(
                                recipe.id,
                                "RECIPE",
                                recipe.titleHindi,
                                recipe.ageGroupLabel
                            )
                        },
                        onOpen = { onOpenRecipe(recipe) },
                        onShare = {
                            val shareText = "🍳 ${recipe.titleHindi} (${recipe.titleEnglish})\nआयु वर्ग: ${recipe.ageGroupLabel}\n\nसामग्री:\n" +
                                    recipe.ingredients.joinToString("\n") { "• $it" } +
                                    "\n\nआयुर्वेदिक लाभ: ${recipe.ayurvedicBenefits}\n\nसावधानी/टिप: ${recipe.cautionOrTip}"
                            onShare(shareText, recipe.titleHindi)
                        }
                    )
                }

                // 4. DEVELOPMENTAL MILESTONES (विकासात्मक पड़ाव)
                if (milestoneInfo != null) {
                    item {
                        MilestonesSection(
                            info = milestoneInfo,
                            accentColor = accentColor,
                            containerColor = containerColor
                        )
                    }
                }

                // 5. NUTRITION & CRITICAL RULES (क्या खाएं और किन चीजों से बचें / जरूरी बातें व नियम)
                item {
                    AgeNutritionRulesSection(
                        ageGroupId = ageGroupId,
                        accentColor = accentColor,
                        containerColor = containerColor
                    )
                }

                // Disclaimer
                item {
                    Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                        DisclaimerCard()
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(
    title: String,
    subtitle: String? = null,
    icon: String? = null,
    accentColor: Color = PrimaryEmerald
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Text(text = icon, fontSize = 24.sp, modifier = Modifier.padding(end = 10.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
        if (subtitle != null) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun DayDietCard(
    dayPlan: DayDietPlan,
    accentColor: Color,
    containerColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .testTag("card_day_${dayPlan.dayId}")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(containerColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = dayPlan.dayNameHindi.take(2),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dayPlan.dayNameHindi,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${dayPlan.dayNameEnglish})",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${dayPlan.meals.size} पहर आहार • नाश्ता, दोपहर, शाम, रात",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(containerColor.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForwardIos,
                    contentDescription = "विवरण देखें",
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun RecipeCard(
    recipe: Recipe,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onOpen: () -> Unit,
    onShare: () -> Unit
) {
    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .testTag("card_recipe_${recipe.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(PastelPeach),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = recipe.iconEmoji, fontSize = 28.sp)
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = recipe.titleHindi,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = recipe.titleEnglish,
                        style = MaterialTheme.typography.bodySmall,
                        color = PastelPeachAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = onToggleBookmark,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("btn_bookmark_${recipe.id}")
                ) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                        contentDescription = "बुकमार्क करें",
                        tint = if (isBookmarked) PastelPeachAccent else TextMuted
                    )
                }

                IconButton(
                    onClick = onShare,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "शेयर करें",
                        tint = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = PastelMint.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "आयुर्वेदिक लाभ:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = recipe.ayurvedicBenefits,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 22.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppLightBackground
                ) {
                    Text(
                        text = "🥗 ${recipe.ingredients.size} मुख्य सामग्री",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                TextButton(
                    onClick = onOpen,
                    modifier = Modifier.height(40.dp)
                ) {
                    Text(
                        text = "विधि देखें",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = PrimaryEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ComplementaryFeedingSection(
    onShare: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, InfantContainer),
            shadowElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header with child nutrition icon
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(InfantPastel)
                            .border(1.5.dp, InfantContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🥄", fontSize = 24.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "अन्नप्राशन और पूरक आहार के नियम",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = InfantAccent
                        )
                        Text(
                            text = "शिशु के संपूर्ण पोषण की वैज्ञानिक शुरुआत",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "6 माह पूर्ण होने के उपरांत केवल मां का दूध शिशु की बढ़ती ऊर्जा और सूक्ष्म पोषक तत्वों (विशेषकर आयरन और जिंक) की पूर्ति के लिए पर्याप्त नहीं होता। अतः सुपाच्य ठोस आहार का समावेश अनिवार्य है।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Texture Stages with step icons
                Text(
                    text = "आहार की बनावट और गाढ़ापन (Texture Stages):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                val stageIcons = listOf("🥣", "🍌", "🥕")
                KidsHealthData.babyTextureStages.forEachIndexed { idx, (stage, desc) ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = InfantPastel,
                        border = androidx.compose.foundation.BorderStroke(1.dp, InfantContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = stageIcons.getOrElse(idx) { "🥣" }, fontSize = 18.sp)
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = stage,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = InfantAccent
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToddlerNutritionSection(
    onShare: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, ToddlerContainer),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(ToddlerPastel),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🥛", fontSize = 24.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "टॉडलर पोषण सिद्धांत (1–3 वर्ष)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ToddlerAccent
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                KidsHealthData.toddlerPrinciples.forEach { (title, content) ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = ToddlerPastel,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ToddlerContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = ToddlerAccent
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                lineHeight = 23.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PreschoolNutritionSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, PreschoolContainer),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(PreschoolPastel),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🍱", fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "स्कूल टिफिन गोल्डन रूल्स (4–6 वर्ष)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PreschoolAccent
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                val rules = listOf(
                    "1. टिफिन कभी भी सूखा और नीरस न रखें।",
                    "2. फल हमेशा अलग छोटे डिब्बे में दें।",
                    "3. पराठे में सब्जियां गूंथ कर दें ताकि बच्चा निकाल न सके।",
                    "4. चना सत्तू गर्मियों में बच्चों को लू से बचाता है और तुरंत ऊर्जा प्रदान करता है।"
                )
                rules.forEach { rule ->
                    Text(
                        text = rule,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 24.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SchoolNutritionSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, SchoolContainer),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(SchoolPastel),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🧠", fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "स्कूल एज न्यूट्रिशन व ब्रेन-बूस्टर्स (7–10 वर्ष)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SchoolAccent
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                val points = listOf(
                    "• कद्दू के बीज (Pumpkin Seeds) बच्चों के पेट के कीड़ों (Worms) को प्राकृतिक रूप से नष्ट करते हैं।",
                    "• मछली या अलसी के बीज ओमेगा-3 के श्रेष्ठ स्रोत हैं, जो बच्चों की आंखों की रोशनी बढ़ाते हैं।",
                    "• ब्राह्मी और शंखपुष्पी मेध्य रसायन हैं जो याददाश्त और फोकस को दोगुना करते हैं।",
                    "• शाम को भारी मैदे के स्नैक्स की जगह जड़ों का सूप (Root Veg Soup) दें।"
                )
                points.forEach { point ->
                    Text(
                        text = point,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 24.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun MilestonesSection(
    info: AgeMilestoneInfo,
    accentColor: Color,
    containerColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        SectionTitle(
            title = "विकासात्मक पड़ाव (Milestones)",
            subtitle = info.intro,
            icon = "🌱",
            accentColor = accentColor
        )

        val categoryIcons = listOf("🦷", "🏃", "🗣️", "🧠")
        info.categories.forEachIndexed { index, category ->
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color.White,
                shadowElevation = 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(containerColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = categoryIcons.getOrElse(index) { "⭐" }, fontSize = 18.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = category.categoryName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    category.items.forEach { item ->
                        Text(
                            text = "• $item",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            lineHeight = 23.sp,
                            modifier = Modifier.padding(vertical = 3.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = PastelPeach,
            border = androidx.compose.foundation.BorderStroke(1.dp, PastelPeachContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(text = "💡", fontSize = 20.sp, modifier = Modifier.padding(end = 8.dp))
                Text(
                    text = info.parentTip,
                    style = MaterialTheme.typography.bodyMedium,
                    color = OnHoneyContainer,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
fun AgeNutritionRulesSection(
    ageGroupId: AgeGroupId,
    accentColor: Color,
    containerColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("section_nutrition_rules")
    ) {
        SectionTitle(
            title = "क्या खाएं और किन चीजों से बचें",
            subtitle = when (ageGroupId) {
                AgeGroupId.INFANT_6_12M -> "शिशु के लिए अनुशंसित अमृत आहार एवं 1 वर्ष तक वर्जित खाद्य पदार्थ"
                AgeGroupId.TODDLER_1_3Y -> "1 से 3 वर्ष के बच्चों के लिए सही आहार चयन एवं जरूरी नियम"
                AgeGroupId.PRESCHOOL_4_6Y -> "4 से 6 वर्ष के बच्चों के लिए संतुलित थाली एवं खाद्य नियम"
                AgeGroupId.SCHOOL_7_10Y -> "7 से 10 वर्ष के बच्चों के लिए ब्रेन-बूस्टर्स एवं स्वस्थ आदतें"
            },
            icon = "🛡️",
            accentColor = accentColor
        )

        val rulesData = when (ageGroupId) {
            AgeGroupId.INFANT_6_12M -> NutritionRulesData(
                allowedTitle = "अमृत आहार (Recommended)",
                allowedItems = KidsHealthData.babyAllowedFoods,
                avoidTitle = "1 वर्ष तक वर्जित (Avoid)",
                avoidItems = KidsHealthData.babyForbiddenFoods.map { "${it.first}: ${it.second}" },
                extraTipTitle = "शिशु पोषण का 3-दिवसीय नियम (Allergy Rule)",
                extraTipContent = "कोई भी नया अनाज, फल या दाल शुरू करते समय लगातार 3 दिन तक केवल वही दें, ताकि किसी भी संभावित एलर्जी या अपच की तुरंत पहचान हो सके।"
            )
            AgeGroupId.TODDLER_1_3Y -> NutritionRulesData(
                allowedTitle = "क्या खिलाएं (Recommended)",
                allowedItems = listOf(
                    "दूध की सीमा: 24 घंटे में अधिकतम 350-400 मिली (2 छोटे कप)",
                    "देसी गाय का शुद्ध A2 घी (प्रतिदिन 1-2 चम्मच)",
                    "रागी, मखाना व घर का ताजा पनीर (कैल्शियम युक्त)",
                    "दाल, रोटी, खिचड़ी, मौसमी हरी सब्जियां व फल",
                    "प्राकृतिक मीठा (गुड़, खजूर सिरप, धागे वाली मिश्री)"
                ),
                avoidTitle = "किन चीजों से बचें (Avoid)",
                avoidItems = listOf(
                    "अत्यधिक दूध पिलाना (मिल्क एनीमिया / भूख न लगने का मुख्य कारण)",
                    "रात को बोतल से दूध (दांतों में कीड़े व सड़न का खतरा)",
                    "सफेद चीनी, चॉकलेट व पैकेज्ड बिस्कुट",
                    "जबरदस्ती खाना खिलाना (Force-Feeding)"
                ),
                extraTipTitle = "सेल्फ-फीडिंग एवं नो-प्रेशर प्लेटिंग नियम",
                extraTipContent = "बच्चे को स्वयं अपने हाथों से खाने दें। थोड़ा खाना गिरेगा, लेकिन इससे भोजन के प्रति सकारात्मक लगाव और आत्मनिर्भरता विकसित होती है।"
            )
            AgeGroupId.PRESCHOOL_4_6Y -> NutritionRulesData(
                allowedTitle = "थाली में क्या जोड़ें (Recommended)",
                allowedItems = listOf(
                    "इंद्रधनुषी थाली (प्रतिदिन कम से कम 3 रंगों की सब्जियां/फल)",
                    "भीगे बादाम व अखरोट (स्मरण शक्ति व एकाग्रता हेतु)",
                    "अंकुरित मूंग/चना व घर का बना सत्तू",
                    "ताजा गुनगुना सूप, छाछ व मौसमी फल"
                ),
                avoidTitle = "किन चीजों से दूर रखें (Avoid)",
                avoidItems = listOf(
                    "पैकेट वाले चिप्स, कुरकुरे व प्रिजर्वेटिव युक्त स्नैक्स",
                    "कोल्ड ड्रिंक्स व डिब्बाबंद फ्रूट जूस",
                    "मैदा, नूडल्स व बाजार का जंक फूड",
                    "टीवी या मोबाइल दिखाते हुए भोजन कराना"
                ),
                extraTipTitle = "स्क्रीन-मुक्त भोजन का स्वर्णिम सूत्र",
                extraTipContent = "स्क्रीन देखकर खाने से लार और पाचक रस सही नहीं बनते। पूरे परिवार के साथ बैठकर शांत वातावरण में भोजन करने की आदत डालें।"
            )
            AgeGroupId.SCHOOL_7_10Y -> NutritionRulesData(
                allowedTitle = "मस्तिष्क व शक्तिवर्धक आहार (Recommended)",
                allowedItems = listOf(
                    "कद्दू के बीज (पेट के कीड़े प्राकृतिक रूप से नष्ट करें)",
                    "अलसी व अखरोट (ओमेगा-3 - आंखों की रोशनी व तीव्र बुद्धि)",
                    "हल्दी वाला गुनगुना दूध (रोग-प्रतिरोधक क्षमता)",
                    "मौसमी फल, सलाद व हरी पत्तेदार सब्जियां"
                ),
                avoidTitle = "किन चीजों से सतर्क रहें (Avoid)",
                avoidItems = listOf(
                    "अत्यधिक कैफीन, चाय, कॉफी व एनर्जी ड्रिंक्स",
                    "अत्यधिक फ्राइड स्नैक्स व स्ट्रीट फूड",
                    "देर रात भारी भोजन और तुरंत सो जाना",
                    "भोजन के तुरंत पहले या बाद में ठंडा पानी पीना"
                ),
                extraTipTitle = "स्वस्थ दिनचर्या का नियम",
                extraTipContent = "प्रतिदिन 8-10 गिलास पानी, 1 घंटा आउटडोर खेलकूद और 9 घंटे की गहरी नींद बच्चों के शारीरिक व मानसिक विकास की मजबूत नींव है।"
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Allowed Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = PastelMint,
                border = androidx.compose.foundation.BorderStroke(1.dp, PastelMintContainer),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "✅", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = rulesData.allowedTitle,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = PastelMintAccent
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    rulesData.allowedItems.forEach { item ->
                        Text(
                            text = "• $item",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }

            // Avoid Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = PastelPink,
                border = androidx.compose.foundation.BorderStroke(1.dp, PastelPinkContainer),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "❌", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = rulesData.avoidTitle,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = PastelPinkAccent
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    rulesData.avoidItems.forEach { item ->
                        Text(
                            text = "• $item",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Extra Golden Rule Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PastelPeach,
            border = androidx.compose.foundation.BorderStroke(1.dp, PastelPeachContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(text = "⭐", fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp))
                Column {
                    Text(
                        text = rulesData.extraTipTitle,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = OnHoneyContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = rulesData.extraTipContent,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

private data class NutritionRulesData(
    val allowedTitle: String,
    val allowedItems: List<String>,
    val avoidTitle: String,
    val avoidItems: List<String>,
    val extraTipTitle: String,
    val extraTipContent: String
)
