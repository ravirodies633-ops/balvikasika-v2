package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE itemId = :id)")
    fun isBookmarked(id: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE itemId = :id")
    suspend fun removeBookmark(id: String)
}

@Dao
interface GrowthLogDao {
    @Query("SELECT * FROM growth_logs ORDER BY id DESC")
    fun getAllGrowthLogs(): Flow<List<GrowthLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrowthLog(log: GrowthLogEntity)

    @Query("DELETE FROM growth_logs WHERE id = :id")
    suspend fun deleteGrowthLog(id: Long)
}
