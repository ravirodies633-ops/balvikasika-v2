package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm, Cute Pediatric Parenting Theme Palette
val PrimaryEmerald = Color(0xFF1E6B52)
val PrimaryDarkEmerald = Color(0xFF134E3F)
val PrimaryLightMint = Color(0xFFE8F5E9)
val OnPrimaryMint = Color(0xFF0F3E2F)

// Sky Blue App Bar Gradients & Header Tones
val SkyBlueGradientStart = Color(0xFFE3F2FD)
val SkyBlueGradientCenter = Color(0xFFEBF6FD)
val SkyBlueGradientEnd = Color(0xFFFAFAF7)
val SkyBluePrimary = Color(0xFF0288D1)

// Specific 4 Age-group Cards Tones (User Requested):
// Card 1: 6–12 माह (Soft pastel-yellow/mint)
val AgeCard1Bg = Color(0xFFF5FCE8)
val AgeCard1Border = Color(0xFFE2F3C8)
val AgeCard1Accent = Color(0xFF388E3C)

// Card 2: 1–3 वर्ष (Soft pastel blush pink)
val AgeCard2Bg = Color(0xFFFFF0F3)
val AgeCard2Border = Color(0xFFFDDCE4)
val AgeCard2Accent = Color(0xFFD81B60)

// Card 3: 4–6 वर्ष (Soft pastel sky blue)
val AgeCard3Bg = Color(0xFFEDF7FE)
val AgeCard3Border = Color(0xFFD7EEFE)
val AgeCard3Accent = Color(0xFF0288D1)

// Card 4: 7–10 वर्ष (Soft pastel lavender/purple)
val AgeCard4Bg = Color(0xFFF4EFFF)
val AgeCard4Border = Color(0xFFE7DBFF)
val AgeCard4Accent = Color(0xFF7B1FA2)

// Compatibility aliases for age groups
val InfantPastel = AgeCard1Bg
val InfantAccent = AgeCard1Accent
val InfantContainer = AgeCard1Border

val ToddlerPastel = AgeCard2Bg
val ToddlerAccent = AgeCard2Accent
val ToddlerContainer = AgeCard2Border

val PreschoolPastel = AgeCard3Bg
val PreschoolAccent = AgeCard3Accent
val PreschoolContainer = AgeCard3Border

val SchoolPastel = AgeCard4Bg
val SchoolAccent = AgeCard4Accent
val SchoolContainer = AgeCard4Border

// Pastel Colors
val PastelMint = Color(0xFFE8F5E9)
val PastelMintAccent = Color(0xFF2E7D32)
val PastelMintContainer = Color(0xFFC8E6C9)

val PastelSkyBlue = Color(0xFFE1F5FE)
val PastelSkyAccent = Color(0xFF0288D1)
val PastelSkyContainer = Color(0xFFB3E5FC)

val PastelPeach = Color(0xFFFFF3E0)
val PastelPeachAccent = Color(0xFFE65100)
val PastelPeachContainer = Color(0xFFFFCC80)

val PastelLavender = Color(0xFFF3E5F5)
val PastelLavenderAccent = Color(0xFF7B1FA2)
val PastelLavenderContainer = Color(0xFFE1BEE7)

val PastelPink = Color(0xFFFCE4EC)
val PastelPinkAccent = Color(0xFFC2185B)
val PastelPinkContainer = Color(0xFFF8BBD0)

// Dos and Don'ts Tones
val DoCardBg = Color(0xFFE8F8F0)
val DoCardBorder = Color(0xFFC6EED9)
val DoCardAccent = Color(0xFF1B5E20)

val DontCardBg = Color(0xFFFFF0F2)
val DontCardBorder = Color(0xFFFFD6DC)
val DontCardAccent = Color(0xFFC62828)

// Ayurvedic Golden Tones
val GoldPrimary = Color(0xFFB78103)
val GoldContainer = Color(0xFFFFF8E1)

// Clean, bright light backgrounds
val AppLightBackground = Color(0xFFFAFAF7)
val CardBackground = Color(0xFFFFFFFF)
val CardBorder = Color(0xFFEBECE7)

// High-contrast, easy-to-read typography
val TextPrimary = Color(0xFF19231E)
val TextSecondary = Color(0xFF43534B)
val TextMuted = Color(0xFF708378)
val OnHoneyContainer = Color(0xFF5D4037)

// Legacy aliases
val ForestGreenPrimary = PrimaryEmerald
val CoralSecondary = Color(0xFFE67E22)
val SoftCream = Color(0xFFFDFCF7)
val SoftPeach = Color(0xFFFFF5EB)
val HoneyContainer = PastelPeach
val HoneyTertiary = PastelPeachAccent
val SageGreen = PrimaryEmerald
val MintPrimaryContainer = PastelMint
val OnMintContainer = PrimaryDarkEmerald
val CoralContainer = PastelPeach
val OnCoralContainer = PastelPeachAccent
val DividerColor = CardBorder
