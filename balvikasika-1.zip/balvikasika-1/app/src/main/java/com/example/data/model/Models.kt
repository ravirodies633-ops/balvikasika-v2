package com.example.data.model

enum class AgeGroupId(
    val title: String,
    val subtitle: String,
    val emoji: String,
    val shortRange: String,
    val description: String,
    val imageUrl: String
) {
    INFANT_6_12M(
        title = "6–12 माह",
        subtitle = "नवजात शिशु (शुरुआती पूरक आहार)",
        emoji = "👶",
        shortRange = "6-12M",
        description = "पूरक आहार (Complementary Feeding) की शुरुआत, दांत निकलना और बैठने के पड़ाव।",
        imageUrl = "https://i.postimg.cc/yYN5wxpH/balvikasika-6-12-months.png"
    ),
    TODDLER_1_3Y(
        title = "1–3 वर्ष",
        subtitle = "छोटे बच्चे (टॉडलर हुड)",
        emoji = "👧",
        shortRange = "1-3Y",
        description = "20 दूध के दांत, चलना-दौड़ना, बोलना और दूध व ठोस आहार का संतुलित सामंजस्य।",
        imageUrl = "https://i.postimg.cc/6q6WsKgq/balvikasika-1-3-years-4500KB.png"
    ),
    PRESCHOOL_4_6Y(
        title = "4–6 वर्ष",
        subtitle = "स्कूल से पहले के बच्चे (प्री-स्कूल)",
        emoji = "🧒",
        shortRange = "4-6Y",
        description = "सूक्ष्म गत्यात्मक कौशल, समय बोध, स्कूल टिफिन और ऊर्जावान दिनचर्या।",
        imageUrl = "https://i.postimg.cc/7LqQnL2V/balvikasika-4-6-years-4500KB.png"
    ),
    SCHOOL_7_10Y(
        title = "7–10 वर्ष",
        subtitle = "स्कूल जाने वाले बच्चे",
        emoji = "🎒",
        shortRange = "7-10Y",
        description = "स्थायी दांत, खेलकूद स्टैमिना, बौद्धिक एकाग्रता और ब्रेन-बूस्टर पोषण।",
        imageUrl = "https://i.postimg.cc/jq6cZTRc/balvikasika-7-10-years-4500KB.png"
    );

    companion object {
        fun fromId(id: String): AgeGroupId = entries.find { it.name == id } ?: INFANT_6_12M
    }
}

data class MilestoneCategory(
    val categoryName: String,
    val items: List<String>
)

data class AgeMilestoneInfo(
    val ageGroupId: AgeGroupId,
    val title: String,
    val intro: String,
    val categories: List<MilestoneCategory>,
    val parentTip: String
)

data class MealSlot(
    val timeLabel: String,
    val mealName: String,
    val ayurvedicBenefit: String
)

data class DayDietPlan(
    val dayId: String,
    val dayNameHindi: String,
    val dayNameEnglish: String,
    val ageGroupId: AgeGroupId,
    val note: String,
    val meals: List<MealSlot>,
    val dailyAyurvedicTip: String
)

data class Recipe(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val ageGroupId: AgeGroupId,
    val ageGroupLabel: String,
    val ingredients: List<String>,
    val preparationSteps: List<String>,
    val ayurvedicBenefits: String,
    val cautionOrTip: String,
    val iconEmoji: String
)

data class GoldenParentingRule(
    val number: Int,
    val title: String,
    val englishTitle: String,
    val description: String,
    val emoji: String
)

data class GrowthStandard(
    val ageLabel: String,
    val ageMonths: Float,
    val minWeightKg: Float,
    val maxWeightKg: Float,
    val minHeightCm: Float,
    val maxHeightCm: Float,
    val majorMilestoneFocus: String
)

data class ClinicalTip(
    val title: String,
    val category: String,
    val forAge: String,
    val instructions: String,
    val benefits: String,
    val emoji: String
)
