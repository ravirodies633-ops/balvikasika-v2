package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Recipe
import com.example.data.repository.KidsHealthData
import com.example.ui.theme.*

@Composable
fun SearchDialog(
    onDismiss: () -> Unit,
    onOpenRecipe: (Recipe) -> Unit
) {
    var query by remember { mutableStateOf("") }

    val filteredRecipes = remember(query) {
        if (query.isBlank()) emptyList()
        else {
            KidsHealthData.allRecipes.filter {
                it.titleHindi.contains(query, ignoreCase = true) ||
                        it.titleEnglish.contains(query, ignoreCase = true) ||
                        it.ingredients.any { ing -> ing.contains(query, ignoreCase = true) } ||
                        it.ayurvedicBenefits.contains(query, ignoreCase = true)
            }
        }
    }

    val filteredRules = remember(query) {
        if (query.isBlank()) emptyList()
        else {
            KidsHealthData.goldenRules.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.englishTitle.contains(query, ignoreCase = true) ||
                        it.description.contains(query, ignoreCase = true)
            }
        }
    }

    val filteredTips = remember(query) {
        if (query.isBlank()) emptyList()
        else {
            (KidsHealthData.digestiveFireTips + KidsHealthData.immunityBoosters).filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true) ||
                        it.instructions.contains(query, ignoreCase = true) ||
                        it.benefits.contains(query, ignoreCase = true)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 20.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Search Input Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("उदा. सेब, मूंग दाल, खिचड़ी, भूख, घी, सत्तू...") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = PrimaryEmerald)
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(
                                    onClick = { query = "" },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "हटाएं")
                                }
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryEmerald,
                            focusedLeadingIconColor = PrimaryEmerald
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_text_field")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text("बंद करें", fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (query.isBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(PastelMint),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🔍", fontSize = 32.sp)
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "गाइड में कोई भी सामग्री या लक्षण खोजें",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "जैसे: सेब प्यूरी, मखाना, मूंग खिचड़ी, सत्तू, जठराग्नि, हींग लेप, हल्दी दूध",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                } else if (filteredRecipes.isEmpty() && filteredRules.isEmpty() && filteredTips.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "\"$query\" के लिए कोई परिणाम नहीं मिला।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        // Recipes
                        if (filteredRecipes.isNotEmpty()) {
                            item {
                                Text(
                                    text = "पौष्टिक रेसिपीज (${filteredRecipes.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryEmerald,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                            items(filteredRecipes) { recipe ->
                                Surface(
                                    onClick = {
                                        onOpenRecipe(recipe)
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(18.dp),
                                    color = PastelPeach,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PastelPeachContainer),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = recipe.iconEmoji, fontSize = 24.sp)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = recipe.titleHindi,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = "${recipe.ageGroupLabel} • ${recipe.titleEnglish}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = PastelPeachAccent,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Clinical Tips
                        if (filteredTips.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "क्लिनिकल व आयुर्वेदिक उपाय (${filteredTips.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryEmerald,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                            items(filteredTips) { tip ->
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = PastelMint,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PastelMintContainer),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = "${tip.emoji} ${tip.title}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = tip.instructions,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            lineHeight = 20.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Golden Rules
                        if (filteredRules.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "स्वर्णिम नियम (${filteredRules.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryEmerald,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                            items(filteredRules) { rule ->
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = PastelLavender,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PastelLavenderContainer),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = "${rule.emoji} ${rule.number}. ${rule.title}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = rule.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            lineHeight = 20.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
