package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey
    val itemId: String,
    val itemType: String, // "RECIPE", "TIP", "DIET_PLAN"
    val title: String,
    val subtitle: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "growth_logs")
data class GrowthLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val childName: String,
    val ageMonths: Float,
    val weightKg: Float,
    val heightCm: Float,
    val logDate: String,
    val notes: String = ""
)
