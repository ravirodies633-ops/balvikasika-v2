package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.GrowthLogEntity
import com.example.data.model.*
import com.example.data.repository.AppRepository
import com.example.data.repository.KidsHealthData
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainTab(val titleHindi: String, val iconName: String) {
    HOME("होम", "home"),
    IMPORTANT("जरूरी बातें", "star"),
    GROWTH("ग्रोथ ट्रैकर", "chart"),
    ABOUT("हमारे बारे में", "info"),
    SAVED("सेव किए गए", "bookmark")
}

data class UiState(
    val currentTab: MainTab = MainTab.HOME,
    val selectedAgeGroup: AgeGroupId? = null,
    val selectedDayPlan: DayDietPlan? = null,
    val selectedRecipe: Recipe? = null,
    val activeAgeSubSection: String = "OVERVIEW", // "OVERVIEW", "MILESTONES", "FEEDING", "WEEKLY_DIET", "RECIPES", "TIPS"
    val searchQuery: String = "",
    val bookmarks: List<BookmarkEntity> = emptyList(),
    val growthLogs: List<GrowthLogEntity> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database)

        viewModelScope.launch {
            repository.allBookmarks.collect { list ->
                _uiState.update { it.copy(bookmarks = list) }
            }
        }

        viewModelScope.launch {
            repository.allGrowthLogs.collect { logs ->
                _uiState.update { it.copy(growthLogs = logs) }
            }
        }
    }

    fun selectTab(tab: MainTab) {
        _uiState.update {
            it.copy(
                currentTab = tab,
                selectedAgeGroup = null,
                selectedDayPlan = null,
                selectedRecipe = null
            )
        }
    }

    fun selectAgeGroup(ageGroupId: AgeGroupId) {
        _uiState.update {
            it.copy(
                selectedAgeGroup = ageGroupId,
                activeAgeSubSection = "OVERVIEW",
                selectedDayPlan = null,
                selectedRecipe = null
            )
        }
    }

    fun clearAgeGroupSelection() {
        _uiState.update {
            it.copy(
                selectedAgeGroup = null,
                selectedDayPlan = null,
                selectedRecipe = null,
                activeAgeSubSection = "OVERVIEW"
            )
        }
    }

    fun setAgeSubSection(section: String) {
        _uiState.update { it.copy(activeAgeSubSection = section) }
    }

    fun selectDayPlan(dayPlan: DayDietPlan) {
        _uiState.update { it.copy(selectedDayPlan = dayPlan) }
    }

    fun clearDayPlan() {
        _uiState.update { it.copy(selectedDayPlan = null) }
    }

    fun selectRecipe(recipe: Recipe) {
        _uiState.update { it.copy(selectedRecipe = recipe) }
    }

    fun clearRecipe() {
        _uiState.update { it.copy(selectedRecipe = null) }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun toggleBookmark(itemId: String, itemType: String, title: String, subtitle: String) {
        viewModelScope.launch {
            val isCurrent = _uiState.value.bookmarks.any { it.itemId == itemId }
            repository.toggleBookmark(itemId, itemType, title, subtitle, isCurrent)
        }
    }

    fun isBookmarked(itemId: String): Boolean {
        return _uiState.value.bookmarks.any { it.itemId == itemId }
    }

    fun addGrowthLog(childName: String, ageMonths: Float, weightKg: Float, heightCm: Float, dateStr: String, notes: String) {
        viewModelScope.launch {
            repository.insertGrowthLog(
                GrowthLogEntity(
                    childName = childName,
                    ageMonths = ageMonths,
                    weightKg = weightKg,
                    heightCm = heightCm,
                    logDate = dateStr,
                    notes = notes
                )
            )
        }
    }

    fun deleteGrowthLog(id: Long) {
        viewModelScope.launch {
            repository.deleteGrowthLog(id)
        }
    }

    fun shareContent(context: Context, text: String, title: String) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_TITLE, title)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "शेयर करें")
        context.startActivity(shareIntent)
    }
}
