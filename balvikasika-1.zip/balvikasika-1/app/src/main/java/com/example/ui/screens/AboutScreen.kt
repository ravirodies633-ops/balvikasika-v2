package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.repository.KidsHealthData
import com.example.ui.components.DisclaimerCard
import com.example.ui.theme.*

@Composable
fun AboutScreen(
    modifier: Modifier = Modifier
) {
    var showPrivacyDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppLightBackground)
            .testTag("screen_about"),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 40.dp)
    ) {
        // App Title Banner (Clean, light pastel card with emerald accents)
        item {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PastelMintContainer),
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(PastelMint)
                            .border(2.dp, PastelMintContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🌿", fontSize = 32.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "बालविकासिका",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = PrimaryDarkEmerald
                    )

                    Text(
                        text = "बाल पोषण एवं विकास मार्गदर्शिका",
                        style = MaterialTheme.typography.titleSmall,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PastelMint
                    ) {
                        Text(
                            text = "\"शरीरमाद्यं खलु धर्मसाधनम्\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PrimaryDarkEmerald,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Author Card (Dr. Raviraj Prajapati)
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(PastelSkyBlue)
                                .border(1.5.dp, PastelSkyContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "👨‍⚕️", fontSize = 28.sp)
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = KidsHealthData.AUTHOR_NAME,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Author & Pediatric Wellness Consultant",
                                style = MaterialTheme.typography.labelSmall,
                                color = PrimaryEmerald,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = KidsHealthData.AUTHOR_TITLE,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = PastelPeach,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PastelPeachContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "लेखक का संदेश (Author Note):",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = PastelPeachAccent
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = KidsHealthData.AUTHOR_NOTE,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }
        }

        // Kaumarbhritya 4 Pillars
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "कौमारभृत्य (Ayurvedic Pediatrics) के 4 स्तंभ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val pillars = listOf(
                        Triple("दीपन-पाचन (Digestive Fire Balancing)", "भोजन ऐसा हो जो जठराग्नि पर भारी न पड़े बल्कि स्वाभाविक भूख को प्रदीप्त रखे।", "🔥"),
                        Triple("धातुपोषक (Tissue Nourishment)", "रस से लेकर ओजस तक सातों धातुओं को समान रूप से पोषित करे।", "🌾"),
                        Triple("ओजवर्धक (Immunity Enhancing)", "बच्चों में मौसमी बदलावों से लड़ने की प्राकृतिक शक्ति उत्पन्न करे।", "🛡️"),
                        Triple("मेध्य आहार (Cognitive Enhancers)", "मस्तिष्क की एकाग्रता, स्मृति (Memory) और बौद्धिक क्षमता को निखारे।", "🧠")
                    )

                    val pillarPastels = listOf(
                        PastelPeach to PastelPeachContainer,
                        PastelMint to PastelMintContainer,
                        PastelSkyBlue to PastelSkyContainer,
                        PastelLavender to PastelLavenderContainer
                    )

                    pillars.forEachIndexed { idx, (title, desc, emoji) ->
                        val (bg, bdr) = pillarPastels[idx % pillarPastels.size]
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = bg,
                            border = androidx.compose.foundation.BorderStroke(1.dp, bdr),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(text = emoji, fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp, top = 2.dp))
                                Column {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = desc,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Privacy Policy Card (Google Play Compliance)
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                onClick = { showPrivacyDialog = true },
                shape = RoundedCornerShape(22.dp),
                color = Color.White,
                shadowElevation = 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_privacy_policy")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(PastelMint)
                            .border(1.dp, PastelMintContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🛡️", fontSize = 22.sp)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "गोपनीयता नीति (Privacy Policy)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "100% सुरक्षित • कोई डेटा सर्वर पर नहीं भेजा जाता",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryEmerald,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "विवरण देखें",
                        tint = PrimaryEmerald,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Closing Wish
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = PastelMint,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PastelMintContainer),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "\"सर्वे भवन्तु सुखिनः सर्वे सन्तु निरामयाः\"",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "सभी बच्चे स्वस्थ, सुखी और निरोगी रहें।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Disclaimer
        item {
            Spacer(modifier = Modifier.height(16.dp))
            DisclaimerCard()
        }
    }

    // In-App Privacy Policy Dialog
    if (showPrivacyDialog) {
        PrivacyPolicyDialog(onDismiss = { showPrivacyDialog = false })
    }
}

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit) {
    val scrollState = rememberScrollState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🛡️", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "गोपनीयता नीति (Privacy)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryDarkEmerald
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "बंद करें")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CardBorder)

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(scrollState)
                ) {
                    Text(
                        text = "बालविकासिका (BalVikasika)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Text(
                        text = "बाल पोषण एवं विकास मार्गदर्शिका (6 माह से 10 वर्ष)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = PastelMint,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "✓ 100% ऑफलाइन एवं सुरक्षित",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryDarkEmerald
                            )
                            Text(
                                text = "इस ऐप द्वारा किसी भी प्रकार का व्यक्तिगत डेटा किसी बाहरी सर्वर या क्लाउड पर नहीं भेजा जाता है।",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                lineHeight = 19.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "1. डेटा संग्रहण (Data Collection):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "• कोई लॉगिन या खाता बनाने की आवश्यकता नहीं है।\n• पसंदीदा रेसिपी व टिप्स केवल आपके फोन की आंतरिक मेमोरी (Room Database) में सुरक्षित रहते हैं।\n• बच्चे की ग्रोथ ट्रैकिंग (वजन, लंबाई, नाम) की जानकारी पूर्णतः ऑफलाइन रहती है और फोन से बाहर नहीं जाती।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "2. अनुमतियां (Device Permissions):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "यह ऐप फोन के कैमरे, लोकेशन (GPS), माइक्रोफ़ोन, संपर्क (Contacts) या स्टोरेज की कोई भी संवेदनशील अनुमति नहीं मांगता है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "3. बाल सुरक्षा (Families Policy & COPPA):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "यह ऐप अभिभावकों व परिजनों के मार्गदर्शन हेतु है। यह बच्चों की निजता का पूर्ण सम्मान करता है एवं Google Play Families Policy व COPPA नियमों का शत-प्रतिशत पालन करता है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "4. विज्ञापन एवं तृतीय पक्ष (No Ads):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "ऐप में कोई विज्ञापन (Ads) नहीं हैं और न ही कोई थर्ड-पार्टी ट्रैकिंग SDKs शामिल हैं।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "5. डेटा विलोपन (Data Deletion):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "आप ऐप में किसी भी समय दर्ज रिकॉर्ड हटा सकते हैं, अथवा ऐप का डेटा क्लियर या अनइंस्टॉल करके संपूर्ण रिकॉर्ड नष्ट कर सकते हैं।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "6. संपर्क (Developer Contact):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "डेवलपर ईमेल: ravirodies633@gmail.com\nएप्लिकेशन आईडी: com.aistudio.balvikasika.wpmzk",
                        style = MaterialTheme.typography.bodySmall,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 20.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                ) {
                    Text("समझ गया / बंद करें", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
